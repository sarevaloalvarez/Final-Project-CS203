import java.util.*;
import java.io.*;
class CS203Final{
    public static void main(String[] args)throws IOException{
        long start=System.currentTimeMillis();
      
        ArrayList<ArrayList<String>> sched=loadArr();
        HashMap<String,Team> teams= loadTeams(sched);
        printList(teams);
        long end= System.currentTimeMillis();
        System.out.println("time "+(end-start));
    }
   
    public static ArrayList<ArrayList<String>> loadArr()throws IOException{
        Scanner file= new Scanner(new File("desktop/CSFinal/NFL_Schedule.csv"));
        ArrayList<ArrayList<String>> sched= new ArrayList<ArrayList<String>>();
        while(file.hasNext()){
            String line=file.nextLine();
            //index of starting character
            int c=0;
            ArrayList<String> temp = new ArrayList<String>();
            for(int i=0;i<line.length();i++){
                if(line.charAt(i)==','){
                    if(!line.substring(c,i).equals(""))
                        temp.add(line.substring(c,i));
                    else if(temp.size()==2 && line.substring(c,i).equals(""))
                        temp.add("vs");
                    else
                        temp.add(null);
                    c=i+1;
                }
                if(i == line.length()-1){
                    if(!line.substring(c).equals(""))
                        temp.add(line.substring(c));
                    else    
                        temp.add(null);
                }
            }
            sched.add(temp);
        }
        return sched;
    }
    public static HashMap<String,Team> loadTeams(ArrayList<ArrayList<String>> sched)throws IOException{
         Scanner teamList= new Scanner(new File("desktop/CSFinal/nflTeams.txt"));
         HashMap<String,Team> teams= new HashMap<String,Team>();
         while(teamList.hasNext()){
            ArrayList<ArrayList<String>> teamSched=new ArrayList<ArrayList<String>>();
            String[] team=teamList.nextLine().split(":");
            for(ArrayList<String> arr:sched){
                if(arr.get(1).equals(team[1]) || arr.get(3).equals(team[1]))
                    teamSched.add(arr);
            }
            teams.put(team[1],new Team(team,teamSched));
        }
        return teams;
    }
    public static void printList(HashMap<String,Team> teams){
        List<Team> NFL= new ArrayList<>();
        List<Team> temp= new ArrayList<>();
        String[] conferences={"AFC", "NFC"};
        String[] divisions={"North","South","East","West"};
        for(int i=0;i<2;i++){ 
            for(int j=0; j<4;j++){
                Stack<Team> division=new Stack<>();
                String divName=conferences[i]+" "+divisions[j];
                for (String s:teams.keySet()){
                    if(teams.get(s).division.equals(divName))
                        division.add(teams.get(s));
                }
                Collections.sort(division);
                NFL.add(division.pop());
                //pops the remaing teams into temp
                for(int cnt=0;cnt<3;cnt++){temp.add(division.pop());}
                
            }
        }
        Collections.sort(NFL,Collections.reverseOrder());
        Collections.sort(temp,Collections.reverseOrder());
        for(Team t:temp)
            NFL.add(t);
        System.out.println("\nNFL Standings\n");
        
        int index=0;
        while(index<2){
            int i=1;
            System.out.println(conferences[index]);
            for(Team t: NFL) {
                String [] conference= t.division.split(" ");
                if(conference[0].equals(conferences[index])){
                    System.out.println(i+") "+t.name+" "+t.getRecord());
                    i++;
                }    
            } 
        index++;
        }
    }
}