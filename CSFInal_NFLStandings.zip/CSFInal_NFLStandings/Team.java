import java.io.IOException;
import java.util.*;
import java.io.File;
public class Team implements Comparable<Team>{
    String division;
    String name;
    // Team Schedule
    ArrayList<ArrayList<String>> teamSched= new ArrayList<ArrayList<String>>();
    // W-L-D record of the team
    int[] record={0,0,0};
    // W-L-D record of the team against oponents in the same division (used in Comparator)
    int[] divisionalRecord={0,0,0};
    ArrayList<String> divisionalopponents= new ArrayList<String>();
    // W-L-D record of the team against oponents in the same conference (used in Comparator)
    ArrayList<String> conferenceopponents= new ArrayList<String>();
    int[] conferenceRecord={0,0,0};
    //List of all opponents
    ArrayList<String> allopponents= new ArrayList<String>();

    Team(String[] team, ArrayList<ArrayList<String>> teamSched)throws IOException{
        Scanner teamList= new Scanner(new File("desktop/CSFinal/nflTeams.txt"));
        this.division=team[0];
        this.name=team[1]; 
        while(teamList.hasNextLine()){
            String[] temp= teamList.nextLine().split(":");
            //teams in same division
            if(temp[0].equals(this.division) && !temp[1].equals(this.name))
                divisionalopponents.add(temp[1]);
            //teams in same conference
            if(temp[0].substring(0,3).equals(this.division.substring(0,3)) && !temp[1].equals(this.name))
                conferenceopponents.add(temp[1]);
        }
        this.teamSched=teamSched;
        for(ArrayList<String> arr: teamSched){
            if(arr.get(4)==null){}

            else if(game(arr,1,this.name)){
                allopponents.add(arr.get(3));
                record[0]++;
                if(divisionalopponents.contains(arr.get(3)))
                    divisionalRecord[0]++;
                if(conferenceopponents.contains(arr.get(3)))
                    conferenceRecord[0]++;
            }
            else if(game(arr,3,this.name)){
                allopponents.add(arr.get(1));
                record[1]++;
                if(divisionalopponents.contains(arr.get(1)))
                    divisionalRecord[1]++;
                if(conferenceopponents.contains(arr.get(1)))
                    conferenceRecord[1]++;
            }
            else{
                if(arr.get(1).equals(name))
                    allopponents.add(arr.get(3));
                else if(arr.get(3).equals(name))
                    allopponents.add(arr.get(1));
                record[2]++;
                if(divisionalopponents.contains(arr.get(1)) || divisionalopponents.contains(arr.get(3)))
                    divisionalRecord[2]++;
                if(conferenceopponents.contains(arr.get(3)) || conferenceopponents.contains(arr.get(3)))
                    conferenceRecord[2]++;
            }
        }
    }
    //W-L-D record of team
    String getRecord(){
        String rec=record[0]+"-"+record[1]+"-"+record[2];
        return rec;
    }
    //Games won over total Games Played
    Double getWinPercentage(int[] record){
        double wp= record[0]+record[2]/2.0;
        wp/=wp+record[1]+record[2]/2.0; 
        return wp;
    }
   
    public int compareTo(Team another){
        int compareWinPercentage= this.getWinPercentage(this.record).compareTo(another.getWinPercentage(another.record));
        //if equal winPercentage
        if( compareWinPercentage == 0){
            // win/loss compared to the other team
            int[] headToHead={0,0};
            for(ArrayList<String> game:this.teamSched){
                // indicates loss
                if(game(game,1,another.name)){
                    headToHead[1]++;
                }
                //indicates win
                if(game(game,3,another.name)){
                    headToHead[0]++;
                }
            //In the event of a tie, neither slot ticks up
            }
            int compareHeadToHead= Integer.compare(headToHead[0], headToHead[1]);
            //teamshave an equal number of wins againsts each other and are a part of the same division
            if(compareHeadToHead == 0 && this.division.equals(another.division)){
                //compares the two teams Divional Record
                int compareDWinPercentage= this.getWinPercentage(this.divisionalRecord).compareTo(another.getWinPercentage(another.divisionalRecord));
                //equal Divional Records
                if(compareDWinPercentage==0){
                    //Record against common opponents 
                    int[] thiscommongameRecord={0,0,0};
                    int[] anothercommongameRecord={0,0,0};
                    for(String opp:allopponents){
                        if(another.allopponents.contains(opp)){
                            if(game(this.teamSched.get(this.allopponents.indexOf(opp)), 1,this.name))
                                thiscommongameRecord[0]++;  
                            
                            else if(game(this.teamSched.get(this.allopponents.indexOf(opp)),3,this.name))
                                thiscommongameRecord[1]++;
                            else
                                thiscommongameRecord[2]++;
                            if(game(another.teamSched.get(another.allopponents.indexOf(opp)),1,another.name))
                                anothercommongameRecord[0]++;
                            else if(game(another.teamSched.get(another.allopponents.indexOf(opp)),3,another.name))
                                anothercommongameRecord[1]++; 
                            else
                            anothercommongameRecord[2]++;      
                        }
                    }
                    //compare Common Game Record
                    int compareCGR= this.getWinPercentage(thiscommongameRecord).compareTo(another.getWinPercentage(anothercommongameRecord));
                    return compareCGR;
                }
                return compareDWinPercentage;
            }
            // teamshave an equal number of wins againsts each other and are NOT a part of the same division
            else if(compareHeadToHead == 0 && !this.division.equals(another.division)){
                int compareCWinPercentage= this.getWinPercentage(this.conferenceRecord).compareTo(another.getWinPercentage(another.conferenceRecord));
                if(compareCWinPercentage == 0){
                    //Record against common opponents 
                    int[] thiscommongameRecord={0,0,0};
                    int[] anothercommongameRecord={0,0,0};
                    for(String opp:allopponents){
                        if(another.allopponents.contains(opp)){
                            if(game(this.teamSched.get(this.allopponents.indexOf(opp)), 1,this.name))
                                thiscommongameRecord[0]++;  
                            
                            else if(game(this.teamSched.get(this.allopponents.indexOf(opp)),3,this.name))
                                thiscommongameRecord[1]++;
                            else
                                thiscommongameRecord[2]++;
                            if(game(another.teamSched.get(another.allopponents.indexOf(opp)),1,another.name))
                                anothercommongameRecord[0]++;
                            else if(game(another.teamSched.get(another.allopponents.indexOf(opp)),3,another.name))
                                anothercommongameRecord[1]++; 
                            else
                            anothercommongameRecord[2]++;      
                        }
                    }
                    //compare Common Game Record
                    int compareCGR= this.getWinPercentage(thiscommongameRecord).compareTo(another.getWinPercentage(anothercommongameRecord));
                    return compareCGR;
                }
                return compareCWinPercentage;
            }
            return compareHeadToHead;   
            }
        return compareWinPercentage;
    }
    //checks whether the a team won or lost a particular game index 1 checks for win index 3 checks for loss
    boolean game(ArrayList<String> game, int index,String name){
        if(game.get(4) !=null && game.get(index).equals(name) &&  Integer.parseInt(game.get(4))> Integer.parseInt(game.get(5)) )
            return true;
        else
            return false;
    }
}
