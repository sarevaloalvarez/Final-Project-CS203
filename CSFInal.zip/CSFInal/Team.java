import java.util.*;
public class Team implements Comparable<Team>{
    // division[0]=Team's conference division[1]= Team's division
    String division;
    String name;
    // Team Schedule
    ArrayList<ArrayList<String>> teamSched= new ArrayList<ArrayList<String>>();

    // W-L-D record of the team
    int[] record={0,0,0};
    
    Team(String[] team, ArrayList<ArrayList<String>> teamSched){
        this.division=team[0];
        this.name=team[1];
        this.teamSched=teamSched;
        for(ArrayList<String> arr: teamSched){
            if(arr.get(4)==null){}

            else if(arr.get(1).equals(name) && Integer.parseInt(arr.get(4))>Integer.parseInt(arr.get(5)))
                record[0]++;
            else if(arr.get(3).equals(name) && Integer.parseInt(arr.get(4))>Integer.parseInt(arr.get(5)))
                record[1]++;
            else
                record[2]++;
        }
    }
    String getRecord(){
        String rec=record[0]+"-"+record[1]+"-"+record[2];
        return rec;
    }
    //Games won over total Games Played
    Double getWinPercentage(){
        double wp= record[0]+record[2]/2.0;
        wp/=wp+record[1]+record[2]/2.0; 
        return wp;
    }

    public int compareTo(Team another){
        int compareWinPercentage= this.getWinPercentage().compareTo(another.getWinPercentage());
        //if equal winPercentage
        if( compareWinPercentage == 0){
            // win/loss compared to the other team
            int[] headToHead={0,0};
            for(ArrayList<String> game:this.teamSched){
                // indicates loss
                if(game.get(1).equals(another.name) && game.get(4) != null)
                    headToHead[1]++;
                //indicates win
                if(game.get(3).equals(another.name) && game.get(4) != null)
                    headToHead[0]++;
            //In the event of a tie, both win and loss array slots tick ups 
            }
            int compareHeadToHead= Integer.compare(headToHead[0], headToHead[1]);
            //teams never played one another or have an equal number of wins againsts each other
            if(compareHeadToHead == 0){
                int[] divisionRecord={0,0};
                for(ArrayList<String> game:this.teamSched){
                    // indicates loss
                    if(game.get(1).equals(another.name) && game.get(4) != null)
                    divisionRecord[1]++;
                    //indicates win
                    if(game.get(3).equals(another.name) && game.get(4) != null)
                    divisionRecord[0]++;
                //In the event of a tie, both win and loss array slots tick ups 
                }
            }
            return compareHeadToHead;   
            }
        return compareWinPercentage;
    }
}
